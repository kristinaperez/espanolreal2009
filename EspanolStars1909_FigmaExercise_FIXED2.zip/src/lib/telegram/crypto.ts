import { createHash, createHmac, timingSafeEqual } from "node:crypto";

/**
 * Server-side verification of Telegram identity data.
 *
 * Two Telegram authentication formats are supported:
 *  1. Login Widget  — flat fields (id, first_name, ..., auth_date, hash)
 *  2. Mini App      — initData string (user=<json>&auth_date=...&hash=...)
 *
 * They use different Telegram-specified secret-key derivations. The bot token
 * never leaves the server.
 */

export interface TelegramAuthUser {
  id: number;
  firstName?: string;
  lastName?: string;
  username?: string;
  photoUrl?: string;
  languageCode?: string;
  isPremium?: boolean;
}

export function getBotToken(): string | null {
  const raw = process.env.TELEGRAM_BOT_TOKEN;
  if (!raw) return null;
  // Netlify/Vercel environment variables are sometimes pasted with quotes.
  // Telegram tokens themselves never contain surrounding quotes.
  const token = raw.trim().replace(/^(?:"|')|(?:"|')$/g, "").trim();
  return token.length > 10 ? token : null;
}

export function getBotUsername(): string | null {
  const username = process.env.TELEGRAM_BOT_USERNAME ?? process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME;
  return username ? username.replace(/^@/, "").trim() : null;
}

export function isTelegramConfigured(): boolean {
  return getBotToken() !== null;
}

function dataCheckString(entries: Record<string, string>): string {
  return Object.keys(entries)
    .filter((key) => key !== "hash" && key !== "signature")
    .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))
    .map((key) => `${key}=${entries[key]}`)
    .join("\n");
}

function safeEqual(a: string, b: string): boolean {
  const bufferA = Buffer.from(a);
  const bufferB = Buffer.from(b);
  if (bufferA.length !== bufferB.length) return false;
  return timingSafeEqual(bufferA, bufferB);
}

export function maxAuthAgeSeconds(): number {
  const raw = Number(process.env.TELEGRAM_AUTH_MAX_AGE);
  return Number.isFinite(raw) && raw > 0 ? raw : 86_400;
}

/**
 * Verifies raw key/value pairs coming from Telegram.
 * Returns the verified user, or null when the signature or freshness check fails.
 */
export function verifyTelegramAuth(
  entries: Record<string, string>,
): { user: TelegramAuthUser; authDate: number } | null {
  const token = getBotToken();
  const hash = entries.hash;
  if (!token || !hash) return null;

  const secret = createHash("sha256").update(token).digest();
  const expected = createHmac("sha256", secret).update(dataCheckString(entries)).digest("hex");
  if (!safeEqual(expected, hash)) return null;

  const authDate = Number(entries.auth_date ?? 0);
  if (!Number.isFinite(authDate) || authDate <= 0) return null;
  const age = Math.floor(Date.now() / 1000) - authDate;
  if (age > maxAuthAgeSeconds() || age < -300) return null;

  let user: TelegramAuthUser | null = null;

  if (entries.user) {
    try {
      // Telegram sends snake_case keys here.
      const parsed = JSON.parse(entries.user) as Record<string, unknown>;
      const id = Number(parsed.id);
      if (Number.isFinite(id)) {
        user = {
          id,
          firstName: typeof parsed.first_name === "string" ? parsed.first_name : undefined,
          lastName: typeof parsed.last_name === "string" ? parsed.last_name : undefined,
          username: typeof parsed.username === "string" ? parsed.username : undefined,
          photoUrl: typeof parsed.photo_url === "string" ? parsed.photo_url : undefined,
          languageCode: typeof parsed.language_code === "string" ? parsed.language_code : undefined,
          isPremium: parsed.is_premium === true,
        };
      }
    } catch {
      user = null;
    }
  }

  if (!user && entries.id) {
    const id = Number(entries.id);
    if (Number.isFinite(id)) {
      user = {
        id,
        firstName: entries.first_name,
        lastName: entries.last_name,
        username: entries.username,
        photoUrl: entries.photo_url,
        languageCode: entries.language_code,
        isPremium: entries.is_premium === "true",
      };
    }
  }

  return user ? { user, authDate } : null;
}

export type TelegramAuthVerification =
  | { ok: true; user: TelegramAuthUser; authDate: number }
  | { ok: false; reason: "not_configured" | "missing_hash" | "bad_hash" | "bad_auth_date" | "expired" | "missing_user" };

/** Same verification as verifyTelegramAuth, but exposes a safe diagnostic reason for the login API. */
export function verifyTelegramAuthDetailed(entries: Record<string, string>): TelegramAuthVerification {
  const token = getBotToken();
  const hash = entries.hash;
  if (!token) return { ok: false, reason: "not_configured" };
  if (!hash) return { ok: false, reason: "missing_hash" };

  const secret = createHash("sha256").update(token).digest();
  const expected = createHmac("sha256", secret).update(dataCheckString(entries)).digest("hex");
  if (!safeEqual(expected, hash)) return { ok: false, reason: "bad_hash" };

  const authDate = Number(entries.auth_date ?? 0);
  if (!Number.isFinite(authDate) || authDate <= 0) return { ok: false, reason: "bad_auth_date" };
  const age = Math.floor(Date.now() / 1000) - authDate;
  if (age > maxAuthAgeSeconds() || age < -300) return { ok: false, reason: "expired" };

  let user: TelegramAuthUser | null = null;
  if (entries.user) {
    try {
      const parsed = JSON.parse(entries.user) as Record<string, unknown>;
      const id = Number(parsed.id);
      if (Number.isFinite(id)) {
        user = {
          id,
          firstName: typeof parsed.first_name === "string" ? parsed.first_name : undefined,
          lastName: typeof parsed.last_name === "string" ? parsed.last_name : undefined,
          username: typeof parsed.username === "string" ? parsed.username : undefined,
          photoUrl: typeof parsed.photo_url === "string" ? parsed.photo_url : undefined,
          languageCode: typeof parsed.language_code === "string" ? parsed.language_code : undefined,
          isPremium: parsed.is_premium === true,
        };
      }
    } catch {
      user = null;
    }
  }

  if (!user && entries.id) {
    const id = Number(entries.id);
    if (Number.isFinite(id)) {
      user = {
        id,
        firstName: entries.first_name,
        lastName: entries.last_name,
        username: entries.username,
        photoUrl: entries.photo_url,
        languageCode: entries.language_code,
        isPremium: entries.is_premium === "true",
      };
    }
  }

  return user ? { ok: true, user, authDate } : { ok: false, reason: "missing_user" };
}

/** Parses a Mini App `initData` query string into raw key/value pairs. */
export function parseInitData(initData: string): Record<string, string> {
  const params = new URLSearchParams(initData);
  const entries: Record<string, string> = {};
  for (const [key, value] of params.entries()) {
    entries[key] = value;
  }
  return entries;
}

/**
 * Verifies Telegram Mini App `initData`.
 *
 * IMPORTANT: Mini Apps use a different secret-key derivation from the
 * Telegram Login Widget. The Mini App secret key is:
 *   HMAC-SHA256(key="WebAppData", message=bot_token)
 * and the resulting key is used to HMAC the data-check string.
 */
export function verifyInitData(initData: string): { user: TelegramAuthUser; authDate: number } | null {
  const token = getBotToken();
  if (!token || !initData) return null;

  const entries = parseInitData(initData);
  const hash = entries.hash;
  if (!hash) return null;

  const secret = createHmac("sha256", "WebAppData").update(token).digest();
  const expected = createHmac("sha256", secret).update(dataCheckString(entries)).digest("hex");
  if (!safeEqual(expected, hash)) return null;

  const authDate = Number(entries.auth_date ?? 0);
  if (!Number.isFinite(authDate) || authDate <= 0) return null;
  const age = Math.floor(Date.now() / 1000) - authDate;
  if (age > maxAuthAgeSeconds() || age < -300) return null;

  let user: TelegramAuthUser | null = null;
  if (entries.user) {
    try {
      const parsed = JSON.parse(entries.user) as Record<string, unknown>;
      const id = Number(parsed.id);
      if (Number.isFinite(id)) {
        user = {
          id,
          firstName: typeof parsed.first_name === "string" ? parsed.first_name : undefined,
          lastName: typeof parsed.last_name === "string" ? parsed.last_name : undefined,
          username: typeof parsed.username === "string" ? parsed.username : undefined,
          photoUrl: typeof parsed.photo_url === "string" ? parsed.photo_url : undefined,
          languageCode: typeof parsed.language_code === "string" ? parsed.language_code : undefined,
          isPremium: parsed.is_premium === true,
        };
      }
    } catch {
      user = null;
    }
  }

  return user ? { user, authDate } : null;
}

export function displayName(user: TelegramAuthUser): string {
  return [user.firstName, user.lastName].filter(Boolean).join(" ") || user.username || `id ${user.id}`;
}
